#ifndef _ROS_james_msgs_Barometer_h
#define _ROS_james_msgs_Barometer_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"

namespace james_msgs
{

  class Barometer : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      typedef float _absolute_alt_type;
      _absolute_alt_type absolute_alt;
      typedef float _relative_alt_type;
      _relative_alt_type relative_alt;
      typedef float _temperature_type;
      _temperature_type temperature;

    Barometer():
      header(),
      absolute_alt(0),
      relative_alt(0),
      temperature(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      union {
        float real;
        uint32_t base;
      } u_absolute_alt;
      u_absolute_alt.real = this->absolute_alt;
      *(outbuffer + offset + 0) = (u_absolute_alt.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_absolute_alt.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_absolute_alt.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_absolute_alt.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->absolute_alt);
      union {
        float real;
        uint32_t base;
      } u_relative_alt;
      u_relative_alt.real = this->relative_alt;
      *(outbuffer + offset + 0) = (u_relative_alt.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_relative_alt.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_relative_alt.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_relative_alt.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->relative_alt);
      union {
        float real;
        uint32_t base;
      } u_temperature;
      u_temperature.real = this->temperature;
      *(outbuffer + offset + 0) = (u_temperature.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_temperature.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_temperature.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_temperature.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->temperature);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      union {
        float real;
        uint32_t base;
      } u_absolute_alt;
      u_absolute_alt.base = 0;
      u_absolute_alt.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_absolute_alt.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_absolute_alt.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_absolute_alt.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->absolute_alt = u_absolute_alt.real;
      offset += sizeof(this->absolute_alt);
      union {
        float real;
        uint32_t base;
      } u_relative_alt;
      u_relative_alt.base = 0;
      u_relative_alt.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_relative_alt.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_relative_alt.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_relative_alt.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->relative_alt = u_relative_alt.real;
      offset += sizeof(this->relative_alt);
      union {
        float real;
        uint32_t base;
      } u_temperature;
      u_temperature.base = 0;
      u_temperature.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_temperature.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_temperature.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_temperature.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->temperature = u_temperature.real;
      offset += sizeof(this->temperature);
     return offset;
    }

    const char * getType(){ return "james_msgs/Barometer"; };
    const char * getMD5(){ return "1d49b6bd6d53a5931b42f9143bddefdf"; };

  };

}
#endif
